/*
 *   line-line - Calculate intersection between two lines
 *   Copyright (C) 2000 Ulf Jordan
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


int
main(int argc, char **argv)
{
  double k1, m1, k2, m2;
  double x, y;

  printf ("Parameters of first line:\n");
  printf ("k1: "); scanf("%le", &k1);
  printf ("m1: "); scanf("%le", &m1);
  printf ("Parameters of second line:\n");
  printf ("k2: "); scanf("%le", &k2);
  printf ("m2: "); scanf("%le", &m2);

  if (k1 != k2)
    {
      x = (m2 - m1)/(k1 - k2);
      y = (k1*m2 - k2*m1)/(k1 - k2);
      printf ("Intersection point: (%f %f)\n", x, y);
    }
  else
    {
      printf ("There is no intersection\n");
    }
}
