%
%    misc-fixed-iso10646-1 - Outline monospaced ISO 10646 font
%    Copyright (C) 2000  Ulf Jordan
%
%    This library is free software; you can redistribute it and/or
%    modify it under the terms of the GNU Lesser General Public
%    License as published by the Free Software Foundation; either
%    version 2.1 of the License, or (at your option) any later version.
%
%    This library is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
%    Lesser General Public License for more details.
%
%    You should have received a copy of the GNU Lesser General Public
%    License along with this library; if not, write to the Free Software
%    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%


% Header file for the misc-fixed outline font
% Definition of global values for the outline elements


% Now we define the symbol to remember that we have been here.
/_MISC-FIXED_H 1 def



% Font parameters
% Parameters which would otherwise collide with already defined names are
% prepended with font_.
%
/FontName /Misc-Fixed def
/font_version (000.003) def
/Notice (Copyright (C) 2000 Ulf Jordan.  This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation; either version 2.1 of the License, or (at your option) any later version.) def
/FullName (Misc-Fixed) def
/FamilyName (Fixed) def
/Weight (Medium) def
/ItalicAngle 0 def
/isFixedPitch true def
/UnderlinePosition -77 def
/UnderlineThickness 38 def
/PaintType 0 def
%/UniqueID 4100000 def
/lenIV 0 def
% EncodingScheme controls how the default encoding vector of the font is 
% generated. It will be set as follows:
%
%  EncodingScheme           Default Encoding vector (in pfa file)
%  ==============================================================
%  AdobeStandardEncoding    StandardEncoding
%  FontSpecific             /Encoding defined in this file
%  (more schemes might be added)
/EncodingScheme (FontSpecific) def
%/EncodingScheme (AdobeStandardEncoding) def
/Encoding [ % C0 Controls, Basic Latin, C1 Controls, and Latin-1 Supplement
/.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef
/.notdef /.notdef /.notdef /uni000B /uni000C /uni000D /uni000E /.notdef
/.notdef /.notdef /uni0012 /.notdef /.notdef /uni0015 /uni0016 /.notdef
/.notdef /uni0019 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef
/space /exclam /quotedbl /numbersign /dollar /percent /ampersand /quotesingle
/parenleft /parenright /asterisk /plus /comma /minus /period /slash
/zero /one /two /three /four /five /six /seven
/eight /nine /colon /semicolon /less /equal /greater /question
/at /A /B /C /D /E /F /G
/H /I /J /K /L /M /N /O
/P /Q /R /S /T /U /V /W
/X /Y /Z /bracketleft /backslash /bracketright /asciicircum /underscore
/grave /a /b /c /d /e /f /g
/h /i /j /k /l /m /n /o
/p /q /r /s /t /u /v /w
/x /y /z /braceleft /bar /braceright /asciitilde /.notdef

/.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef
/.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef
/.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef
/.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef
/space /exclamdown /cent /sterling /currency /yen /brokenbar /section
/dieresis /copyright /ordfeminine /guillemotleft /logicalnot /hyphen 
/registered /macron
/degree /plusminus /twosuperior /threesuperior /acute /mu /paragraph 
/periodcentered
/cedilla /onesuperior /ordmasculine /guillemotright /onequarter /onehalf
/threequarters /questiondown
/Agrave /Aacute /Acircumflex /Atilde /Adieresis /Aring /AE /Ccedilla
/Egrave /Eacute /Ecircumflex /Edieresis /Igrave /Iacute /Icircumflex /Idieresis
/Eth /Ntilde /Ograve /Oacute /Ocircumflex /Otilde /Odieresis /multiply
/Oslash /Ugrave /Uacute /Ucircumflex /Udieresis /Yacute /Thorn /germandbls
/agrave /aacute /acircumflex /atilde /adieresis /aring /ae /ccedilla
/egrave /eacute /ecircumflex /edieresis /igrave /iacute /icircumflex /idieresis
/eth /ntilde /ograve /oacute /ocircumflex /otilde /odieresis /divide
/oslash /ugrave /uacute /ucircumflex /udieresis /yacute /thorn /ydieresis
] def

% Stem width
% Experiment and see if it is beneficial to have the stemwidth divisble by 4.
/sw 77 def

% Width of glyphs
/GlyphWidth sw 6 mul  def

